Write-Host "hoge1"
Write-Host "hoge2"
Write-Host "hoge3"